package com.arwinata.am.skripsi.Retrofit;

public class CheckingConnection {

    private String BASE_URL = "http://192.168.1.7:3000";

    public String getBASE_URL() {
        return BASE_URL;
    }
}
